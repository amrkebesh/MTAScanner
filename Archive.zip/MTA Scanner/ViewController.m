//
//  ViewController.m
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/4/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
