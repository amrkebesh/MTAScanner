//
//  ViewController.h
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/4/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

