//
//  KeyboardButton.h
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/24/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegisterTrainerViewController.h"
#import "KeyboardViewController.h"
@interface KeyboardButton : UIButton
@property (strong, nonatomic) UITextField *numberPad;

@end
