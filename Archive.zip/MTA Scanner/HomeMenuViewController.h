//
//  HomeMenuViewController.h
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/30/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MessageUI/MessageUI.h>

@interface HomeMenuViewController : UIViewController <MFMailComposeViewControllerDelegate>

@end
