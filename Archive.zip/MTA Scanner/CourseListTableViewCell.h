//
//  CourseListTableViewCell.h
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/21/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CourseListTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *codeLabel;
@property (strong, nonatomic) IBOutlet UILabel *courseLabel;

@end
