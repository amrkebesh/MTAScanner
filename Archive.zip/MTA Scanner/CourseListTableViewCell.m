//
//  CourseListTableViewCell.m
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/21/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import "CourseListTableViewCell.h"

@implementation CourseListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
