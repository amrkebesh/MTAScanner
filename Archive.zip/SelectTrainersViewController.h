//
//  SelectTrainersViewController.h
//  MTA Scanner
//
//  Created by Wazir Rafeek on 8/16/17.
//  Copyright © 2017 Wazir Rafeek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScanEmployeesViewController.h"
#import "EmployeeCell.h"
@interface SelectTrainersViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>

@end
